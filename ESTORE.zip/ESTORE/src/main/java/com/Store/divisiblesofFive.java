/**
 * @author priya singh
 * java program to print all the first 20 divisible of 5 without using looping structures
 */


package com.Store;

import java.util.Scanner;             //import scanner to get input from the user 
import static java.lang.System.*;     
import java.util.stream.Stream;

public class divisiblesofFive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//creating scanner object to take users input
				Scanner obj = new Scanner(System.in);
				
				//asking user the limit to print the divisible of 5
				out.println("\t\t\t----------Divisible of  5------------- \nEnter the number till which you want to print the multiple of 5");
				int num = obj.nextInt();
				out.println("\t\t\t**First "+num+" numbers that are Divisible by 5 ** ");
				
			
				//using method reference and stream API
				Stream.iterate(1,i->i+1).filter(i->i%5==0).limit(num).forEach(out::println);
				
				//closing scanner object
				obj.close();
	}

}
