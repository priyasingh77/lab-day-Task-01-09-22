package com.Store;

public class Electronic {
		int EID;
		String Ecompany;
		String EName;
		int Eprice;
		int EModel;
		public Electronic(int eID, String ecompany, String eName, int eprice, int eModel) {
			
			EID = eID;
			Ecompany = ecompany;
			EName = eName;
			Eprice = eprice;
			EModel = eModel;
		}
}
		
