/**
 * @author priya singh
 * write a java program to sort the Laptops whose price is less than 30000,
 * creating ArrayList and apply stream  API features to sort the products
 * 
 */

package com.Store;

import java.util.ArrayList;    //import ArrayList

public class electronicStore {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Creating object to store electronic product data
		Electronic E1=new Electronic(121,"Asus","ROG Strix ",78990,2022);
		Electronic E2=new Electronic(122,"HP","HP Envy 13 ",24990,2021);
		Electronic E3=new Electronic(123,"Lenovo","Lenovo IdeaPad 3 ",30000,2020);
		Electronic E4=new Electronic(124,"Samsung"," Samsung Galaxy S12",38990,2022);
		Electronic E5=new Electronic(125,"Apple","iPhone 14 Pro",120000,2022);
		Electronic E6=new Electronic(126,"Realme","Book",29998,2021);
		
		//Creating Array List
		ArrayList<Electronic> al =new ArrayList<Electronic>();
		al.add(E6);
		al.add(E5);
		al.add(E4);
		al.add(E3);
		al.add(E2);
		al.add(E1);
		// apply  stream API features to sort 
		al.stream().filter(i->i.Eprice<30000)
		.forEach(i->{
            System.out.println(i.Ecompany+" "+i.EName+" Rs: "+i.Eprice);

		
		});
}
}
